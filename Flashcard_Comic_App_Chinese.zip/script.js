
function flipCard(card) {
    card.classList.toggle('flipped');
    document.getElementById('flip-sound').play();

    const isFlipped = card.classList.contains('flipped');
    if (isFlipped) {
        const utterance = new SpeechSynthesisUtterance("nǐ hǎo");
        utterance.lang = 'zh-CN';
        speechSynthesis.speak(utterance);
    }
}
